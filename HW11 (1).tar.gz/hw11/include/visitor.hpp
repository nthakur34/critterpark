#ifndef _BEN120_VISITOR_HPP
#define _BEN120_VISITOR_HPP

#include <iostream>
#include <string>

class Visitor {




};

#endif

