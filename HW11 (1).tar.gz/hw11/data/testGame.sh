#!/bin/bash

../bin/hw11 < ../data/test1.txt
